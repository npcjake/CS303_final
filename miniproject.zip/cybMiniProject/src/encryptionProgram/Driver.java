package encryptionProgram;


public class Driver {

	public static void main(String[] args) {
		UserInterface ui = new UserInterface();
		ui.userPrompt();
	}
}
